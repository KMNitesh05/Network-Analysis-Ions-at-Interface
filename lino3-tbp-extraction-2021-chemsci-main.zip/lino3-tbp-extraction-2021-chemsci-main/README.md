# LiNO3-TBP-Extraction-2021-ChemSci

This folder contains relevant data and description of scripts to reproduce analysis in the 2021 Kumar et. al. Unexpected Inverse Correlations and Cooperativity in Ion-pair Phase Transfer, in Chemical Science.